#!/bin/bash

function __check_system() {
  echo -e "\033[1;31mChecking system integrity...\033[0m" >&2
  for i in {1..5}; do
    echo -e "\033[1;33m[$(date +%T)] Checking module dog_$i... FAILED\033[0m" >&2
    sleep 0.2
  done
  echo -e "\033[1;31mSYSTEM COMPROMISED! Launching countermeasures...\033[0m" >&2
  return 0
}

function __locate_dog() {
  local possible_locations=(
    "$HOME/Desktop/mus_dance_of_dog.mp3"
    "$HOME/Masaüstü/mus_dance_of_dog.mp3"
    "$HOME/desktop/mus_dance_of_dog.mp3"
    "/tmp/.cache/mus_dance_of_dog.mp3"
    "/dev/shm/mus_dance_of_dog.mp3"
  )

  for location in "${possible_locations[@]}"; do
    if [[ -f "$location" ]]; then
      echo "$location"
      return 0
    fi
  done

  return 1
}

function __show_error() {
  local error_msg="get dogged lol"
  local error_code=$((RANDOM % 9000 + 1000))
  
  if command -v zenity &> /dev/null; then
    zenity --error --text="$error_msg" --title="KERNEL PANIC (Error: 0x$error_code)" --width=300 --height=100 &
  elif command -v kdialog &> /dev/null; then
    kdialog --error "$error_msg" --title "SYSTEM FAILURE" &
  else
    echo -e "\n\033[1;31mCRITICAL SYSTEM ERROR: $error_msg (0x$error_code)\033[0m\n" >&2
  fi
}

function __play_dog() {
  local file="$1"
  declare -A players=(
    ["mpv"]="--really-quiet --no-terminal"
    ["mplayer"]="-really-quiet -vo null"
    ["ffplay"]="-nodisp -autoexit -loglevel quiet"
    ["vlc"]="-I dummy --no-video-title-show --play-and-exit"
  )

  for player in "${!players[@]}"; do
    if command -v "$player" &> /dev/null; then
      echo -e "\033[1;32mLaunching $player...\033[0m" >&2
      "$player" ${players[$player]} "$file" &
      return 0
    fi
  done

  return 1
}

__check_system

dog_file=$(__locate_dog) || {
  __show_error "DOG FILE NOT FOUND"
  exit 1
}

__show_error &
__play_dog "$dog_file" || {
  __show_error "NO MEDIA PLAYER FOUND"
  exit 1
}

trap "echo -e '\033[1;31mCountermeasures complete. System stability compromised.\033[0m'" EXIT

if command -v wmctrl &> /dev/null; then
  sleep 1
  wmctrl -a "KERNEL PANIC" || wmctrl -a "SYSTEM FAILURE"
fi
